import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;

public class Gigasecond {
    private final static long GIGASECOND = 1_000_000_000L;
    private LocalDateTime ldt;

    public Gigasecond(LocalDate moment) {
        ldt = moment.atStartOfDay().plus(GIGASECOND, ChronoUnit.SECONDS);
    }

    public Gigasecond(LocalDateTime moment) {
        ldt = moment.plus(GIGASECOND, ChronoUnit.SECONDS);
    }

    public LocalDateTime getDateTime() {
        return ldt;
    }
}
