public class TriangleException extends Exception{
    TriangleException(){
        super();
    }
}
