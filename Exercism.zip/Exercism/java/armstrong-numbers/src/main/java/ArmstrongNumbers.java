class ArmstrongNumbers {

    boolean isArmstrongNumber(int numberToCheck) {
        String numb = Integer.toString(numberToCheck);
        int m=numb.length();
        int res=0;
        for (int i=0;i<m;i++)
        {
            res+=Math.pow(Character.getNumericValue(numb.charAt(i)),m);
        }

        return res == numberToCheck;
    }
}
