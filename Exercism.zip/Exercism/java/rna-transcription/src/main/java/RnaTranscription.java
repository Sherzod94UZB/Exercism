class RnaTranscription {

    String transcribe(String dnaStrand) {
        StringBuilder RNA = new StringBuilder();

        if (dnaStrand.isEmpty())
            return "";

        for(int i = 0; i < dnaStrand.length(); i++){

            if(dnaStrand.charAt(i) == 'C')
                RNA.append("G");

            if (dnaStrand.charAt(i) == 'G')
                RNA.append("C");

            if(dnaStrand.charAt(i) == 'T')
                RNA.append("A");

            if(dnaStrand.charAt(i) == 'A')
                RNA.append("U");

        }

        return RNA.toString();
    }

}
