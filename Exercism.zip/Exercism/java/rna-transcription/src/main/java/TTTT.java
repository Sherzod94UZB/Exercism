public class TTTT {
    private static String abc;
    public static void main(String[] args) {
        System.out.println(abc);
    }
}
