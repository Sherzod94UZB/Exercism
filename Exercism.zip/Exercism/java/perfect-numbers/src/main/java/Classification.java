enum Classification {

    DEFICIENT, PERFECT, ABUNDANT

}
