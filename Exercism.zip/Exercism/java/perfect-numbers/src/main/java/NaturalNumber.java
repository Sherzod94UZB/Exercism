class NaturalNumber {

}
