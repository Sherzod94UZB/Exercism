class Darts {
    double rad;

    Darts(double x, double y) {
        rad = Math.sqrt(x * x + y * y);
    }

    int score() {
        if(rad <= 1.0)
            return 10;
        else if(rad <= 5.0)
            return 5;
        else if(rad <= 10.0)
            return 1;
        else
            return 0;
    }
}
