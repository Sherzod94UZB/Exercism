class SumOfMultiples {

    SumOfMultiples(int number, int[] set) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

    int getSum() {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}
