public class PangramChecker {

    public boolean isPangram(String input) {
        throw new UnsupportedOperationException("Delete this statement and write your own implementation.");
    }

}
