import java.util.Arrays;
class ResistorColorDuo {
    int value(String[] colors) {
        StringBuilder abc = new StringBuilder("");

        for (int i = 0; i < 2; i++) {
            abc.append(Arrays.asList(colors()).indexOf(colors[i]));
        }
        return Integer.parseInt(abc.toString());
    }

    String[] colors() {
        return new String[]{"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};
    }
}