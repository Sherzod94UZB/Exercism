class SpaceAge {


    protected double earthYear;
    protected int earthYearInSeconds = 31557600;

    SpaceAge(double seconds) {
        earthYear = seconds / earthYearInSeconds;
    }

    double onEarth() {
        return earthYear;
    }

    double onMercury() {
        return earthYear / 0.2408467;
    }

    double onVenus() {
        return earthYear / 0.61519726;
    }

    double onMars() {
        return earthYear / 1.8808158;
    }

    double onJupiter() {
        return earthYear / 11.862615;
    }

    double onSaturn() {
        return earthYear / 29.447498;
    }

    double onUranus() {
        return earthYear / 84.016846;
    }

    double onNeptune() {
        return earthYear / 164.79132;
    }

}