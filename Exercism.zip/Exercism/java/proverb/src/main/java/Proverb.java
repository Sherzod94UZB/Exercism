class Proverb {
    public String[] wordsStrings;
    Proverb(String[] words) {
        wordsStrings = words;
    }

    String recite() {
        StringBuilder finalString = new StringBuilder();
        for (int i = 1; i <= wordsStrings.length; i++) {
            if (i == wordsStrings.length) {
                finalString.append("And all for the want of a ").append(wordsStrings[0]).append(".");
            } else {
                finalString.append("For want of a ").append(wordsStrings[i - 1]).append(" the ").append(wordsStrings[i]).append(" was lost.\n");
            }
        }
        return finalString.toString();
    }

}
